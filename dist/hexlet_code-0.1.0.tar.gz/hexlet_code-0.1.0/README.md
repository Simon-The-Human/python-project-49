### Hexlet tests and linter status:
[![Actions Status](https://github.com/Simon-The-Human/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Simon-The-Human/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/3359dd1d85137df7075b/maintainability)](https://codeclimate.com/github/Simon-The-Human/python-project-49/maintainability)
